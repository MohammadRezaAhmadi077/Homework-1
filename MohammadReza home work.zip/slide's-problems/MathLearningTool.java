package math.learning.tool;

import java.util.Scanner;

public class MathLearningTool {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int randomnum1, randomnum2;
        randomnum1 = (int) (Math.random() * 10);
        randomnum2 = (int) (Math.random() * 10);
        /* System.out.println(randomnum1);
        System.out.println(randomnum2);*/
        System.out.println("what is the sum of these tow numbers:" + randomnum1 + "+" + randomnum2);
        double sum = input.nextDouble();
        int result = randomnum1 + randomnum2;
        if (sum!=result){
            System.out.println("false");}
        if (sum == result) {
            System.out.println("true");
        } 
    }

}
