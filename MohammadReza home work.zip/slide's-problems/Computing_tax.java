
package computing_tax;
import java.util.Scanner;
public class Computing_tax {

    public static void main(String[] args) {
        Scanner input= new Scanner (System.in);
        System.out.println("enter your income amount");
       double income=input.nextDouble();
        System.out.println("of you are single press 1");
        System.out.println("of you are married jointly press 2");
        System.out.println("of you are married separately press 3");
        System.out.println("of you are head of household press 4");
       int state= input.nextInt();
       if (state ==1){if (income>=0&& income<8350){
       double tax=(income*10)/100.0;
           System.out.println("payable tax: "+tax);
       }else if (income>=8351 && income<33950){
       double tax= (income*15)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=33951 && income<82250){
       double tax = (income*25)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=82251 && income<171550){
           double tax= (income*28)/100d;
           System.out.println("payable tax: "+tax);
               } else if (income>=1711551 && income< 372950){
               double tax = (income*33)/100d;
               System.out.println("pyable tax: "+tax);
               } else if (income>= 372951){
               double tax = (income*35)/100d;
               }
       
    }else if (state ==2){if (income>=0&& income< 16700){
       double tax=(income*10)/100.0;
           System.out.println("payable tax: "+tax);
       }else if (income>=16701 && income<67900){
       double tax= (income*15)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=67901 && income<137050){
       double tax = (income*25)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=137051 && income<208850){
           double tax= (income*28)/100d;
           System.out.println("payable tax: "+tax);
               } else if (income>= 208851 && income<372950){
               double tax= (income*33)/100d;
               System.out.println("payable tax: "+tax);
               }else if (income>= 372951){
               double tax= (income* 35)/100d;
               }
    }
    else if (state ==3){if (income>=0&& income< 8350){
       double tax=(income*10)/100.0;
           System.out.println("payable tax: "+tax);
       }else if (income>=8351 && income<33950){
       double tax= (income*15)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=33951 && income<68525){
       double tax = (income*25)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=68526 && income<104425){
           double tax= (income*28)/100d;
           System.out.println("payable tax: "+tax);
               } else if (income>=104426 && income<186475){
               double tax = (income*33)/100d;
               System.out.println("payable tax: "+ tax);
               } else if (income>=186476){
               double tax=(income*35)/100d;
               System.out.println("payable tax: "+tax);
               }
                   
           } else if (state ==4){if (income>=0&& income< 11950){
       double tax=(income*10)/100.0;
           System.out.println("payable tax: "+tax);
       }else if (income>=11951 && income<45500){
       double tax= (income*15)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=45501 && income<117450){
       double tax = (income*25)/100d;
           System.out.println("payable tax: "+tax);
       }else if (income>=117451 && income<190200){
           double tax= (income*28)/100d;
           System.out.println("payable tax: "+tax);
               } else if (income >=190201 && income<372950){
               double tax= (income*33)/100.0;
               System.out.println("payable tax: "+tax);
               } else if(income>=372951){
               double tax =(income*35)/100d;
               System.out.println("payable tax: "+tax);
               }
    }
    }}
